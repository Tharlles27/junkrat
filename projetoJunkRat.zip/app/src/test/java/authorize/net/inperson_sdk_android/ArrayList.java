package authorize.net.inperson_sdk_android;

public class ArrayList {
    Double totaopay;
    Double labor;

    public Double getTotaopay() {
        return totaopay;
    }

    public void setTotaopay(Double totaopay) {
        this.totaopay = totaopay;
    }

    public Double getLabor() {
        return labor;
    }

    public void setLabor(Double labor) {
        this.labor = labor;
    }
}
