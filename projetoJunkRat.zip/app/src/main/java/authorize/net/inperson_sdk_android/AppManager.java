package authorize.net.inperson_sdk_android;

import net.authorize.Merchant;
import net.authorize.aim.emv.Result;


public class AppManager {

    public static Merchant merchant;
    public static Result lastTransactionResult;

}
